# NeuroSurge Lite offline game

Extract the ZIP and keep the files together. Open [index.html](index.html) to play.

Use [Linux.sh](Linux.sh), [macOS.command](macOS.command), or [Windows.cmd](Windows.cmd) to open the game with the default browser on your computer.

[Simple guide](simple.html) · [Technical guide](technical.html) · [Original game online](https://eliminatenoise.github.io/NeuroSurge/)
